//6.Program for addition of two matrix
import java.util.Scanner; 
import java.io.*;
public class MatrixAddition 
{
public static void main(String[] args) 
{ 
int row,column;
System.out.println("Enter number of rows in matrix: "); 
Scanner in1 =new Scanner(System.in); 
row=in1.nextInt();
System.out.println("Enter number of columns in matrix: "); 
Scanner in =new Scanner(System.in);
column=in.nextInt();
int mat1[][]=new int [row][column]; 
int mat2[][]=new int [row][column]; 
for(int i=0;i<row;i++)
{
for(int j=0;j<column;j++)
{
System.out.println("Enter"+i+"th row and"+j+"th element of first matrix:"); mat1[i][j]=in.nextInt();
}
}
for(int i=0;i<row;i++)
{
for(int j=0;j<column;j++)
{
System.out.println("Enter"+i+"th row and"+j+"th element of second matrix:"); 
mat2[i][j]=in.nextInt();
}
}
System.out.println("Addition of two Matrices"); 
for(int i=0;i<row;i++)
{
for(int j=0;j<column;j++)
{
int temp=mat1[i][j]+mat2[i][j]; 
System.out.println(temp+" ");
}
System.out.println();
}
}
}
