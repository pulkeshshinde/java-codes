//3.Matching Rectangles

import java.io.*; 
import java.util.*;

class Rect 
{
double width, length, area; 
String color;
Scanner sc = new Scanner(System.in); Rect()
{
System.out.println("Enter the length: "); 
length=sc.nextDouble(); 
System.out.println("Enter the Width: "); 
width=sc.nextDouble(); 
System.out.println("Enter the Color: "); 
color=sc.next();
area = length*width;
System.out.println("Area of rectangle : " + area);
}
}

public class demo 
{
public static void main(String[] args) 
{ 
System.out.println("First Rectangle: "); 
Rect r1 = new Rect(); 
System.out.println("Second Rectangle: "); 
Rect r2 = new Rect();

if (r1.area == r2.area&&r1.color.equals(r2.color)) 
{
System.out.println("Matching Rectangles...");
}
else
{
System.out.println("Non Matching Rectangles...");
}
}
}