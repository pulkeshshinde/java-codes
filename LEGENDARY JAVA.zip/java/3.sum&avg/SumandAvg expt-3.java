//EXP 3
import java.util.Scanner; 
public class SumandAvg
{ 
public static void main(String[] args)
{  
double no ,sum=0,avg; 
int n; 
System.out.print("how many num you want to enter"); 
Scanner in = new Scanner(System.in); 
n = in.nextInt(); 
for(int i = 1 ;i<=n;i++) 
{ 
System.out.println("enter the number"); 
no = in.nextDouble(); 
sum+=no; 
} 
avg = sum/n; 
System.out.println("average of"+n+"number is "+avg); 
}
}