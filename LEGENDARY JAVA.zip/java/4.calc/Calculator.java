import java.util.Scanner; 
public class Calculator 
{     
public static void main(String args[])     
{ 
int choice; 
int no1,no2,result; 
do 
{ 
System.out.println("1.add"); 
System.out.println("2.Subtract");  
System.out.println("3.factorial");  
System.out.println("4.Exit");   
System.out.println("Enter your choice");  
Scanner in =new Scanner(System.in);  
choice=in.nextInt();  
switch(choice)
{
case 1:
System.out.println("enter first number");   
no1=in.nextInt(); 
System.out.println("enter second number");   
no2=in.nextInt(); 
result=no1+no2; 
System.out.println("Addition:"+result); 
break;
case 2:
System.out.println ("enter fist number");   
no1=in.nextInt(); 
System.out.println("enter second number");   
no2=in.nextInt(); 
result=no1-no2; 
System.out.println("Subtraction:"+result);  
break; 
case 3:
System.out.println("enter number"); 
no1=in.nextInt(); 
result=1; 
for(int i=1;i<=no1;++i) 
{ 
result *=i; 
} 
System.out.println("Factorial of "+no1 +"is" +result);   
break; 
case 4: 
System.out.println("Terminating");       
break; 
default: 
System.out.println("Wrong choice");   
break; 
     } 
 }
while(choice !=4); 
}
}